package apresentacao;

import negocio.Div;
import negocio.DocumentHtml;
import negocio.Html;
import negocio.Link;
import negocio.Paragraph;
import negocio.TagFim;
import negocio.TitleH1;
import negocio.TitleH2;

public class Main {

    public static void main(String[] args) {
        Html documentHtml = new DocumentHtml();
        documentHtml = new TitleH1(documentHtml, "Título");
        documentHtml = new TitleH2(documentHtml, "Subtítulo");
        documentHtml = new Paragraph(documentHtml, "Mussum Ipsum, cacilds vidis litro abertis. Bota 1 metro de cachacis aí pra viagem! Atirei o pau no gatis, per gatis num morreus. Pellentesque nec nulla ligula. Donec gravida turpis a vulputate ultricies. Leite de capivaris, leite de mula manquis sem cabeça.");
        documentHtml = new Link(documentHtml, "google", "http://www.google.com");
        documentHtml = new Div(documentHtml, "Uma div");
        documentHtml = new TagFim(documentHtml);
        System.out.println(documentHtml.getCode());
        System.out.println("=============");
    }
}
