package negocio;

public class HtmlTagDecorator extends Html {

    protected Html html;

    public HtmlTagDecorator(Html html) {
        this.html = html;
    }

    public String getCode() {
        return this.html.getCode() + "\n " + this.code;

    }

    @Override
    public Html removeTag() {
        return html;
    }
}
