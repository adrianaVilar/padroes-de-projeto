package negocio;

public abstract class Html {

    protected String code;

    public abstract String getCode();

    public Html removeTag(){
        return null;
    }
}
