package negocio;

public class DocumentHtml extends Html {

    @Override
    public String getCode() {
        return "<html>";
    }
}
