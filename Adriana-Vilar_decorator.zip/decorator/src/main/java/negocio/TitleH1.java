package negocio;

public class TitleH1 extends HtmlTagDecorator {

    public TitleH1(Html html, String title) {
        super(html);
        this.code = "<h1>" + title + "</h1>";
    }
}
