package negocio;

public class Link extends HtmlTagDecorator{

    public Link(Html html, String title, String url) {
        super(html);
        this.code = "<a href=\"" + url + "\">" + title + "</a>";
    }
}
