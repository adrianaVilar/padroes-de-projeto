package negocio;

public class TagFim extends HtmlTagDecorator {

    public TagFim(Html html) {
        super(html);
        this.code = "</html>";
    }
}
