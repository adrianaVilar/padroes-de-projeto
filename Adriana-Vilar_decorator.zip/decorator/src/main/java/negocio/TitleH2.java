package negocio;

public class TitleH2 extends HtmlTagDecorator {

    public TitleH2(Html html, String title) {
        super(html);
        this.code = "<h2>" + title + "</h2>";
    }
}
