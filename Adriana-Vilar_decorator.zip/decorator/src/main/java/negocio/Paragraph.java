package negocio;

public class Paragraph extends HtmlTagDecorator {

    public Paragraph(Html html, String paragraph) {
        super(html);
        this.code = "<p>" + paragraph + "</p>";
    }
}
