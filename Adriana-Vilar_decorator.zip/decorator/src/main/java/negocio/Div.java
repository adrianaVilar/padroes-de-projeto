package negocio;

public class Div extends HtmlTagDecorator {

    public Div(Html html, String text) {
        super(html);
        this.code = "<div>" + text + "</div>";
    }
}
